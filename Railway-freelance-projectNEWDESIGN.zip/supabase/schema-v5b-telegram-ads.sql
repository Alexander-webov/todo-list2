-- schema-v5b-telegram-ads.sql
-- Добавляет поля для Telegram-размещения в существующую таблицу ads
-- Запустить если таблица ads уже существует

ALTER TABLE ads ADD COLUMN IF NOT EXISTS tg_pin_hours INT DEFAULT 2;
ALTER TABLE ads ADD COLUMN IF NOT EXISTS tg_keep_hours INT DEFAULT 48;
ALTER TABLE ads ADD COLUMN IF NOT EXISTS tg_posted_at TIMESTAMPTZ;
ALTER TABLE ads ADD COLUMN IF NOT EXISTS tg_message_id BIGINT;

-- schema-v9-retention.sql
-- Расширяет applications статусами, добавляет избранное и ловлю email-ов у анонимов

-- ─── 1. Статусы откликов ───
ALTER TABLE applications ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'sent';
-- 'sent' | 'responded' | 'accepted' | 'rejected' | 'closed_lost'
ALTER TABLE applications ADD COLUMN IF NOT EXISTS status_updated_at TIMESTAMPTZ;
ALTER TABLE applications ADD COLUMN IF NOT EXISTS deal_amount NUMERIC;
ALTER TABLE applications ADD COLUMN IF NOT EXISTS notes TEXT;

CREATE INDEX IF NOT EXISTS idx_apps_user_status
  ON applications (user_id, status, created_at DESC);

-- ─── 2. Избранное (сохранённые проекты) ───
CREATE TABLE IF NOT EXISTS saved_projects (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, project_id)
);

CREATE INDEX IF NOT EXISTS idx_saved_user_date
  ON saved_projects (user_id, created_at DESC);

ALTER TABLE saved_projects ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Users read own saved" ON saved_projects;
  DROP POLICY IF EXISTS "Users write own saved" ON saved_projects;
  DROP POLICY IF EXISTS "Service role full saved" ON saved_projects;
END $$;

CREATE POLICY "Users read own saved"
  ON saved_projects FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users write own saved"
  ON saved_projects FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Service role full saved"
  ON saved_projects FOR ALL USING (auth.role() = 'service_role');

-- ─── 3. Захват email у анонимов (exit-intent) ───
CREATE TABLE IF NOT EXISTS email_captures (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
  source TEXT,              -- exit_intent | responded_page | other
  user_agent TEXT,
  ip_hash TEXT,             -- SHA256 от IP для защиты от спама, не сам IP
  converted_to_user UUID REFERENCES profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_captures_email
  ON email_captures (email);

-- ─── 4. Просмотренные проекты (для "скрыть просмотренные") ───
CREATE TABLE IF NOT EXISTS viewed_projects (
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  viewed_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (user_id, project_id)
);

CREATE INDEX IF NOT EXISTS idx_viewed_user_date
  ON viewed_projects (user_id, viewed_at DESC);

ALTER TABLE viewed_projects ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Users read own viewed" ON viewed_projects;
  DROP POLICY IF EXISTS "Users write own viewed" ON viewed_projects;
  DROP POLICY IF EXISTS "Service role full viewed" ON viewed_projects;
END $$;

CREATE POLICY "Users read own viewed"
  ON viewed_projects FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users write own viewed"
  ON viewed_projects FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Service role full viewed"
  ON viewed_projects FOR ALL USING (auth.role() = 'service_role');

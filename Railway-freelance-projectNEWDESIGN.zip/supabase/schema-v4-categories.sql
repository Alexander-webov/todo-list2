-- schema-v4-categories.sql
-- Миграция категорий: старые → новые
-- Запустить один раз в Supabase SQL Editor

-- ============================================================
-- 1. ПЕРЕКЛАССИФИКАЦИЯ ПРОЕКТОВ В ТАБЛИЦЕ projects
-- ============================================================

-- Видеомонтаж (из Design, Другое)
UPDATE projects SET category = 'Видеомонтаж'
WHERE category IN ('Design', 'Другое')
  AND (title || ' ' || COALESCE(description, '')) ~* 
    '(видеомонтаж|монтаж.*видео|видео.*монтаж|видеоролик|premiere|davinci|after\s*effects|моушн|motion\s*design|видеограф|видеоредакт|рилс|reels)';

-- SMM (из Marketing)
UPDATE projects SET category = 'SMM'
WHERE category IN ('Marketing', 'Другое')
  AND (title || ' ' || COALESCE(description, '')) ~* 
    '(smm|постинг|оформлен.*соц|ведени.*соц|ведение.*инст|ведение.*групп|контент.*план|соцсет|продвижен.*соц|таргетолог|ведение.*аккаунт|ведение.*паблик|сториз|stories)';

-- Парсинг (из Data, Backend, Другое)
UPDATE projects SET category = 'Парсинг'
WHERE category IN ('Data', 'Backend', 'Другое')
  AND (title || ' ' || COALESCE(description, '')) ~* 
    '(парсинг|парсер|сбор.*данн|web.*scrap|scraping|selenium|beautifulsoup|telegram.*бот|чат.*бот|бот.*telegram|скрипт.*автоматиз|бот.*для|разработ.*бот|api.*интеграц)';

-- WordPress / Tilda / CMS (из Web Development)
UPDATE projects SET category = 'WordPress / Tilda / CMS'
WHERE category IN ('Web Development', 'Другое')
  AND (title || ' ' || COALESCE(description, '')) ~* 
    '(wordpress|тильда|tilda|wix|bitrix|битрикс|joomla|opencart|modx|drupal|hostcms|squarespace|webflow|shopify|1с-битрикс|cms|конструктор.*сайт|движок.*сайт|установк.*сайт|настройк.*wordpress|плагин.*wordpress|тема.*wordpress|шаблон.*сайт)';

-- Web дизайн (из Design, Web Development)
UPDATE projects SET category = 'Web дизайн'
WHERE category IN ('Design', 'Web Development')
  AND (title || ' ' || COALESCE(description, '')) ~* 
    '(веб.*дизайн|web.*дизайн|дизайн.*сайт|дизайн.*лендинг|дизайн.*магазин|дизайн.*приложен|дизайн.*интерфейс|прототип.*сайт|ui|ux|ui/ux|figma.*сайт|figma.*лендинг|figma.*интерфейс|макет.*сайт)';

-- Графический дизайн (оставшийся Design)
UPDATE projects SET category = 'Графический дизайн'
WHERE category = 'Design';

-- FrontEnd (из Web Development — фреймворки)
UPDATE projects SET category = 'FrontEnd'
WHERE category = 'Web Development'
  AND (title || ' ' || COALESCE(description, '')) ~* 
    '(react|vue|angular|next\.?js|nuxt|typescript|frontend|front[\-\s]?end|фронтенд|svelte|gatsby|remix|webpack|vite|tailwind|redux|javascript.*разработ|spa|pwa)';

-- Вёрстка (из Web Development — чистая HTML/CSS)
UPDATE projects SET category = 'Вёрстка'
WHERE category = 'Web Development'
  AND (title || ' ' || COALESCE(description, '')) ~* 
    '(вёрстк|верстк|html|css|адаптивн|кроссбраузер|pixel.*perfect|натяжк|psd.*to|макет.*верст|респонсив)';

-- BackEnd (из Backend)
UPDATE projects SET category = 'BackEnd'
WHERE category = 'Backend';

-- Остатки Web Development → Другое (если не попали ни в одну)
UPDATE projects SET category = 'Другое'
WHERE category = 'Web Development';

-- Mobile → Другое
UPDATE projects SET category = 'Другое'
WHERE category = 'Mobile';

-- Writing → Другое
UPDATE projects SET category = 'Другое'
WHERE category = 'Writing';

-- Marketing → Другое (оставшиеся после SMM)
UPDATE projects SET category = 'Другое'
WHERE category = 'Marketing';

-- Data → Другое (оставшиеся после Парсинг)
UPDATE projects SET category = 'Другое'
WHERE category = 'Data';

-- DevOps → BackEnd
UPDATE projects SET category = 'BackEnd'
WHERE category = 'DevOps';


-- ============================================================
-- 2. ОБНОВЛЕНИЕ filter_categories В ПРОФИЛЯХ ПОЛЬЗОВАТЕЛЕЙ
-- ============================================================
-- Маппинг старых категорий на новые в пользовательских профилях.
-- Используем jsonb-замену для каждой старой категории.

-- Web Development → FrontEnd
UPDATE profiles
SET filter_categories = (
  SELECT array_agg(
    CASE val
      WHEN 'Web Development' THEN 'FrontEnd'
      WHEN 'Design' THEN 'Графический дизайн'
      WHEN 'Mobile' THEN 'Другое'
      WHEN 'Writing' THEN 'Другое'
      WHEN 'Marketing' THEN 'SMM'
      WHEN 'Data' THEN 'Парсинг'
      WHEN 'Backend' THEN 'BackEnd'
      ELSE val
    END
  )
  FROM unnest(filter_categories) AS val
)
WHERE filter_categories IS NOT NULL
  AND array_length(filter_categories, 1) > 0;


-- ============================================================
-- 3. ПРОВЕРКА РЕЗУЛЬТАТОВ
-- ============================================================
-- Запустите после миграции для проверки:

-- SELECT category, COUNT(*) as cnt
-- FROM projects
-- GROUP BY category
-- ORDER BY cnt DESC;

-- SELECT DISTINCT unnest(filter_categories) as cat, COUNT(*) 
-- FROM profiles 
-- WHERE filter_categories IS NOT NULL 
-- GROUP BY cat 
-- ORDER BY count DESC;

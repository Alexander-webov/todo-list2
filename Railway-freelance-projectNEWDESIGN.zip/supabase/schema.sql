-- ============================================================
-- FreeLance Aggregator — Supabase Schema
-- Выполни этот SQL в Supabase > SQL Editor
-- ============================================================

-- Таблица проектов (основная)
CREATE TABLE IF NOT EXISTS projects (
  id            UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  external_id   TEXT        NOT NULL,
  source        TEXT        NOT NULL,  -- 'upwork' | 'freelancer' | 'fl' | 'habr' | 'kwork'
  title         TEXT        NOT NULL,
  description   TEXT,
  budget_min    NUMERIC,
  budget_max    NUMERIC,
  currency      TEXT        DEFAULT 'USD',
  category      TEXT,
  tags          TEXT[]      DEFAULT '{}',
  url           TEXT        NOT NULL,
  referral_url  TEXT,
  published_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (source, external_id)
);

-- Индексы для быстрой фильтрации
CREATE INDEX IF NOT EXISTS idx_projects_source      ON projects (source);
CREATE INDEX IF NOT EXISTS idx_projects_category    ON projects (category);
CREATE INDEX IF NOT EXISTS idx_projects_created_at  ON projects (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_projects_published_at ON projects (published_at DESC);

-- Пользователи (для Telegram-уведомлений и премиума)
CREATE TABLE IF NOT EXISTS users (
  id              UUID    DEFAULT gen_random_uuid() PRIMARY KEY,
  email           TEXT    UNIQUE,
  telegram_chat_id TEXT   UNIQUE,
  is_premium      BOOLEAN DEFAULT FALSE,
  filter_sources  TEXT[]  DEFAULT '{}',   -- фильтр по биржам
  filter_keywords TEXT[]  DEFAULT '{}',   -- ключевые слова
  filter_categories TEXT[] DEFAULT '{}',  -- категории
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Включаем Realtime для таблицы projects
-- (нужно также включить в Supabase Dashboard > Database > Replication)
ALTER TABLE projects REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE projects;

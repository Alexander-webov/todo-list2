-- schema-v8-roles-and-tracking.sql
-- Роли при регистрации, трекинг откликов, мотивация возврата

-- ─── 1. Поля в profiles ───
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS user_role TEXT;
-- 'designer' | 'videomaker' | 'developer' | 'smm' | 'other'

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_visit_at TIMESTAMPTZ;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS visit_streak INT DEFAULT 0;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_visits INT DEFAULT 0;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS xp INT DEFAULT 0;

-- ─── 2. Таблица откликов ───
CREATE TABLE IF NOT EXISTS applications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
  source TEXT,
  project_score NUMERIC,           -- qualityScore проекта на момент отклика
  project_budget NUMERIC,
  used_ai BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, project_id)
);

CREATE INDEX IF NOT EXISTS idx_apps_user_date
  ON applications (user_id, created_at DESC);

-- ─── 3. RLS ───
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Users read own applications" ON applications;
  DROP POLICY IF EXISTS "Users insert own applications" ON applications;
  DROP POLICY IF EXISTS "Service role full applications" ON applications;
END $$;

CREATE POLICY "Users read own applications"
  ON applications FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users insert own applications"
  ON applications FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Service role full applications"
  ON applications FOR ALL USING (auth.role() = 'service_role');

-- ─── 4. RPC обновления визита со стриком ───
CREATE OR REPLACE FUNCTION ping_user_visit(p_user_id UUID)
RETURNS TABLE (
  streak INT,
  total_visits INT,
  is_new_day BOOLEAN,
  xp INT
) AS $$
DECLARE
  v_last TIMESTAMPTZ;
  v_streak INT := 0;
  v_total INT := 0;
  v_xp INT := 0;
  v_new_day BOOLEAN := FALSE;
  v_hours_since NUMERIC;
BEGIN
  SELECT last_visit_at, visit_streak, total_visits, xp
    INTO v_last, v_streak, v_total, v_xp
  FROM profiles WHERE id = p_user_id;

  -- Рассчитываем разрыв с прошлого визита
  IF v_last IS NULL THEN
    v_streak := 1;
    v_total := 1;
    v_new_day := TRUE;
    v_xp := COALESCE(v_xp, 0) + 10; -- бонус за первый визит
  ELSE
    v_hours_since := EXTRACT(EPOCH FROM (NOW() - v_last)) / 3600.0;

    IF v_hours_since < 20 THEN
      -- тот же день, ничего не начисляем
      v_new_day := FALSE;
    ELSIF v_hours_since < 48 THEN
      -- следующий день, стрик продолжается
      v_streak := COALESCE(v_streak, 0) + 1;
      v_total := COALESCE(v_total, 0) + 1;
      v_new_day := TRUE;
      v_xp := COALESCE(v_xp, 0) + 5 + LEAST(v_streak, 10); -- чем длиннее стрик, тем больше xp
    ELSE
      -- стрик сброшен
      v_streak := 1;
      v_total := COALESCE(v_total, 0) + 1;
      v_new_day := TRUE;
      v_xp := COALESCE(v_xp, 0) + 5;
    END IF;
  END IF;

  UPDATE profiles SET
    last_visit_at = NOW(),
    visit_streak = v_streak,
    total_visits = v_total,
    xp = v_xp
  WHERE id = p_user_id;

  RETURN QUERY SELECT v_streak, v_total, v_new_day, v_xp;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ─── 5. RPC статистики откликов пользователя ───
CREATE OR REPLACE FUNCTION get_application_stats(p_user_id UUID)
RETURNS TABLE (
  total_all INT,
  total_today INT,
  total_week INT,
  avg_score_week NUMERIC,
  last_application_at TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    (SELECT COUNT(*)::INT FROM applications WHERE user_id = p_user_id),
    (SELECT COUNT(*)::INT FROM applications
      WHERE user_id = p_user_id AND created_at >= NOW() - INTERVAL '24 hours'),
    (SELECT COUNT(*)::INT FROM applications
      WHERE user_id = p_user_id AND created_at >= NOW() - INTERVAL '7 days'),
    (SELECT COALESCE(AVG(project_score), 0)::NUMERIC FROM applications
      WHERE user_id = p_user_id AND created_at >= NOW() - INTERVAL '7 days'),
    (SELECT MAX(created_at) FROM applications WHERE user_id = p_user_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
